public interface Display
   {
        public void display();

    }


