public class Login {


    public Login()
    {
        System.out.println("\n\t\t\tWelcome to Nuces Public School");
        System.out.println("\t\t\t================================");
        System.out.println("\n");
    }



}
