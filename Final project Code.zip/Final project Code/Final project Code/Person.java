import java.util.Scanner;

 class Person {

     private String firstName;
     private String lastName;

     private String fatherName,address,gender;
     private int age,contactNo;

     Person(){

    }

    Person(String firstName,String lastName){
         this.firstName=firstName;
         this.lastName=lastName;

    }

     public void setFirstName(String firstName) {
         this.firstName = firstName;
     }

     public void setLastName(String lastName) {
         this.lastName = lastName;
     }

     public String getFirstName() {
         return firstName;
     }

     public String getLastName() {
         return lastName;
     }

    public void input(){
        Scanner sc = new Scanner(System.in);
        System.out.println("\t\t\t\t__________________________________________");
        System.out.print("\t\t\t\tEnter First Name : ");
        this.firstName = sc.next();

        System.out.print("\t\t\t\tEnter Last Name :");
        this.lastName = sc.next();
        System.out.println("\t\t\t\t__________________________________________");



    }



 }
